<?php

include('header.php');

?>
      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
          <div class="row ">
              
              
              
              
                                     <?php
            if($rowuser['type']==0){
            
            ?> 
            
   
            <?php
            
            $querycc=mysqli_query($con,"select * from  company ")or die(mysqli_error());
$rowcc=mysqli_fetch_array($querycc);

$topupmain=$rowcc['topupmain'];
            
            ?>

                               <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <div class="card">
                <div class="card-statistic-4">
                  <div class="align-items-center justify-content-between">
                    <div class="row ">
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pr-0 pt-3">
                        <div class="card-content">
                          <h5 class="font-15">Main Topup Wallet</h5>
                 <h2 class="mb-3 font-26">&#8369; <?php echo number_format($topupmain,2);?></h2>
                         
                        </div>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pl-0">
                        <div class="banner-img">
                          <img src="assets/img/banner/topup.fw.png" alt="">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
                                                                          <?php
              $sp=$rowuser['id'];
$query=mysqli_query($con,"select *  from  user where type='3' and sponsor_id='$sp' and status='Pending'")or die(mysqli_error());
$count=mysqli_num_rows($query);
              ?>
            
            
                                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <div class="card">
                <div class="card-statistic-4">
                  <div class="align-items-center justify-content-between">
                    <div class="row ">
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pr-0 pt-3">
                        <div class="card-content">
                          <h5 class="font-15">Pending Rider Application</h5>
                 <h2 class="mb-3 font-26"><?php echo $count;?></h2>
                         
                        </div>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pl-0">
                        <div class="banner-img">
                          <img src="assets/img/banner/4.png" alt="">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
              
              <?php
              
$query=mysqli_query($con,"select sum(amount) as amount from  code where operator_id!='0'")or die(mysqli_error());
$row=mysqli_fetch_array($query);
              ?>
              
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <div class="card">
                <div class="card-statistic-4">
                  <div class="align-items-center justify-content-between">
                    <div class="row ">
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pr-0 pt-3">
                        <div class="card-content">
                          <h5 class="font-15">Total Sales</h5>
                          <h2 class="mb-3 font-18">&#8369; <?php echo number_format($row['amount'],2);?></h2>
                   
                        </div>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pl-0">
                        <div class="banner-img">
                          <img src="assets/img/banner/1.png" alt="">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
                        
                                     <?php
      
            ?> 
                          <?php
              
$query=mysqli_query($con,"select *  from  code where operator_id!='0'")or die(mysqli_error());
$count=mysqli_num_rows($query);
              ?>
                      <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <div class="card">
                <div class="card-statistic-4">
                  <div class="align-items-center justify-content-between">
                    <div class="row ">
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pr-0 pt-3">
                        <div class="card-content">
                          <h5 class="font-15">Total Code Used</h5>
                          <h2 class="mb-3 font-18"><?php echo $count;?></h2>
                   
                        </div>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pl-0">
                        <div class="banner-img">
                          <img src="assets/img/banner/1.png" alt="">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
                                      <?php
              
$query=mysqli_query($con,"select *  from  code where operator_id='0'")or die(mysqli_error());
$count=mysqli_num_rows($query);
              ?>
                      <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <div class="card">
                <div class="card-statistic-4">
                  <div class="align-items-center justify-content-between">
                    <div class="row ">
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pr-0 pt-3">
                        <div class="card-content">
                          <h5 class="font-15">Total Code Unused</h5>
                          <h2 class="mb-3 font-18"><?php echo $count;?></h2>
                   
                        </div>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pl-0">
                        <div class="banner-img">
                          <img src="assets/img/banner/1.png" alt="">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
                                                  <?php
              
$query=mysqli_query($con,"select *  from  code ")or die(mysqli_error());
$count=mysqli_num_rows($query);
              ?>
                      <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <div class="card">
                <div class="card-statistic-4">
                  <div class="align-items-center justify-content-between">
                    <div class="row ">
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pr-0 pt-3">
                        <div class="card-content">
                          <h5 class="font-15">Total Generated Code</h5>
                          <h2 class="mb-3 font-18"><?php echo $count;?></h2>
                   
                        </div>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pl-0">
                        <div class="banner-img">
                          <img src="assets/img/banner/1.png" alt="">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
                        
                                     <?php
            }
            if($rowuser['type']==0 || $rowuser['type']==1){
            
            ?> 
                                      <?php
              
$query=mysqli_query($con,"select *  from  customer ")or die(mysqli_error());
$count=mysqli_num_rows($query);
              ?>
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <div class="card">
                <div class="card-statistic-4">
                  <div class="align-items-center justify-content-between">
                    <div class="row ">
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pr-0 pt-3">
                        <div class="card-content">
                          <h5 class="font-15"> Customers</h5>
                          <h2 class="mb-3 font-18"><?php echo $count;?></h2>
                         
                        </div>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pl-0">
                        <div class="banner-img">
                          <img src="assets/img/banner/2.png" alt="">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
                                                  <?php
              
$query=mysqli_query($con,"select *  from  user where type='3' ")or die(mysqli_error());
$count=mysqli_num_rows($query);
              ?>
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <div class="card">
                <div class="card-statistic-4">
                  <div class="align-items-center justify-content-between">
                    <div class="row ">
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pr-0 pt-3">
                        <div class="card-content">
                          <h5 class="font-15">Rider</h5>
                    <h2 class="mb-3 font-18"><?php echo $count;?></h2>
                         
                        </div>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pl-0">
                        <div class="banner-img">
                          <img src="assets/img/banner/2.png" alt="">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
                                                              <?php
              
$query=mysqli_query($con,"select *  from  user where type='2'")or die(mysqli_error());
$count=mysqli_num_rows($query);
              ?>
                       <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <div class="card">
                <div class="card-statistic-4">
                  <div class="align-items-center justify-content-between">
                    <div class="row ">
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pr-0 pt-3">
                        <div class="card-content">
                          <h5 class="font-15">Operator</h5>
                <h2 class="mb-3 font-18"><?php echo $count;?></h2>
                         
                        </div>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pl-0">
                        <div class="banner-img">
                          <img src="assets/img/banner/2.png" alt="">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <?php
            }
            if($rowuser['type']==0 ){
            
            ?> 
                     <?php
              
$query=mysqli_query($con,"select sum(tf) as amount from  withdrawals ")or die(mysqli_error());
$row=mysqli_fetch_array($query);






$query21=mysqli_query($con,"select sum(amount) as amount from  code where operator_id>=1")or die(mysqli_error());
$row21=mysqli_fetch_array($query21);
              ?>    
            
            
            
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <div class="card">
                <div class="card-statistic-4">
                  <div class="align-items-center justify-content-between">
                    <div class="row ">
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pr-0 pt-3">
                        <div class="card-content">
                          <h5 class="font-15">Total Cash</h5>
                          <h2 class="mb-3 font-18">&#8369; <?php echo number_format($row['amount']+$row21['amount'],2);?></h2>
                         
                        </div>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pl-0">
                        <div class="banner-img">
                          <img src="assets/img/banner/4.png" alt="">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <?php
            }
            if($rowuser['type']==0 || $rowuser['type']==1){
            
            ?> 
            
            
            
                        <?php
              
$query=mysqli_query($con,"select sum(tf) as amount from  withdrawals where date(date_added)>='$date' ")or die(mysqli_error());
$row=mysqli_fetch_array($query);
              ?>                               
                        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <div class="card">
                <div class="card-statistic-4">
                  <div class="align-items-center justify-content-between">
                    <div class="row ">
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pr-0 pt-3">
                        <div class="card-content">
                          <h5 class="font-15">Today's Withdrawals</h5>
                              <h2 class="mb-3 font-18">&#8369; <?php echo number_format($row['amount_final'],2);?></h2>
                         
                        </div>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pl-0">
                        <div class="banner-img">
                          <img src="assets/img/banner/4.png" alt="">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>     
            
                        
                        <?php
              
$query=mysqli_query($con,"select sum(amount_final) as amount from  withdrawals where status='Pending' ")or die(mysqli_error());
$row=mysqli_fetch_array($query);
              ?>   
            
                                    <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <div class="card">
                <div class="card-statistic-4">
                  <div class="align-items-center justify-content-between">
                    <div class="row ">
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pr-0 pt-3">
                        <div class="card-content">
                          <h5 class="font-15">Total Pending Withdrawals</h5>
                           <h2 class="mb-3 font-18">&#8369; <?php echo number_format($row['amount'],2);?></h2>
                         
                        </div>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pl-0">
                        <div class="banner-img">
                          <img src="assets/img/banner/4.png" alt="">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
                                    <?php
              
$query=mysqli_query($con,"select sum(amount_final) as amount from  withdrawals where status='Completed' ")or die(mysqli_error());
$row=mysqli_fetch_array($query);
              ?>  
            
                                    <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <div class="card">
                <div class="card-statistic-4">
                  <div class="align-items-center justify-content-between">
                    <div class="row ">
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pr-0 pt-3">
                        <div class="card-content">
                          <h5 class="font-15">Total Completed Withdrawals</h5>
                  <h2 class="mb-3 font-18">&#8369; <?php echo number_format($row['amount_final'],2);?></h2>
                         
                        </div>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pl-0">
                        <div class="banner-img">
                          <img src="assets/img/banner/4.png" alt="">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
        <?php
            }
            if($rowuser['type']==0 ){
            
            ?> 
              
            
                                                <?php
              
$query=mysqli_query($con,"select sum(amount) as amount from  reward_history ")or die(mysqli_error());
$row=mysqli_fetch_array($query);
              ?>  


                                    <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <div class="card">
                <div class="card-statistic-4">
                  <div class="align-items-center justify-content-between">
                    <div class="row ">
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pr-0 pt-3">
                        <div class="card-content">
                          <h5 class="font-15">Total Lump Sum Rewards</h5>
                 <h2 class="mb-3 font-18">&#8369; <?php echo number_format($row['amount'],2);?></h2>
                         
                        </div>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pl-0">
                        <div class="banner-img">
                          <img src="assets/img/banner/4.png" alt="">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            
                                         <?php
            }
            
            ?> 
            
            <?php
              if($rowuser['type']==2 ){
            
            ?>
            
              <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col-xs-12">
                <div class="card">
                  <div class="card-header">
                    <h4>Booq Rider App</h4>
                  </div>
                  <div class="card-body">
                      
                              <div class="form-group">
                      <div class="input-group mb-3">
                      <input class="form-control" type="text" value="https://booqph.com/ridenow" id="myInput">
                        <div class="input-group-append">
                          <button class="btn btn-primary" onclick="myFunction()"type="button"><i class="fas fa-copy"></i>Copy</button>
                        </div>
                      </div>
                    </div>
                      
                      
             
                  </div>
                </div>
              </div>
            

<script>
function myFunction() {
  /* Get the text field */
  var copyText = document.getElementById("myInput");

  /* Select the text field */
  copyText.select();
  copyText.setSelectionRange(0, 99999); /* For mobile devices */

  /* Copy the text inside the text field */
  navigator.clipboard.writeText(copyText.value);
  
  /* Alert the copied text */
  alert("Copied link: " + copyText.value);
}
</script>

     <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col-xs-12">
                <div class="card">
                  <div class="card-header">
                    <h4>Operator Rider Application Link</h4>
                  </div>
                  <div class="card-body">
                      
                              <div class="form-group">
                      <div class="input-group mb-3">
                      <input class="form-control" type="text" value="https://booqph.com/booq_rider.php?ref=<?php echo $rowuser['id_number'];?>" id="myInput2">
                        <div class="input-group-append">
                          <button class="btn btn-primary" onclick="myFunction2()"type="button"><i class="fas fa-copy"></i>Copy</button>
                        </div>
                      </div>
                    </div>
                      
                      
             
                  </div>
                </div>
              </div>
            

<script>
function myFunction2() {
  /* Get the text field */
  var copyText = document.getElementById("myInput2");

  /* Select the text field */
  copyText.select();
  copyText.setSelectionRange(0, 99999); /* For mobile devices */

  /* Copy the text inside the text field */
  navigator.clipboard.writeText(copyText.value);
  
  /* Alert the copied text */
  alert("Copied link: " + copyText.value);
}
</script>

            
                  <?php
              $ses=$_SESSION['id'];
$query=mysqli_query($con,"select sum(amount) as amount from  reward_history where user_id='$ses' ")or die(mysqli_error());
$row=mysqli_fetch_array($query);
              ?>  





                                    <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <div class="card">
                <div class="card-statistic-4">
                  <div class="align-items-center justify-content-between">
                    <div class="row ">
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pr-0 pt-3">
                        <div class="card-content">
                          <h5 class="font-15">Personal Wallet</h5>
                 <h2 class="mb-3 font-26">&#8369; <?php echo number_format($rowuser['wallet'],2);?></h2>
                         
                        </div>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pl-0">
                        <div class="banner-img">
                          <img src="assets/img/banner/personal.fw.png" alt="">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            

                               <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <div class="card">
                <div class="card-statistic-4">
                  <div class="align-items-center justify-content-between">
                    <div class="row ">
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pr-0 pt-3">
                        <div class="card-content">
                          <h5 class="font-15">Top Up Wallet</h5>
                 <h2 class="mb-3 font-26">&#8369; <?php echo number_format($rowuser['top_wallet'],2);?></h2>
                         
                        </div>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pl-0">
                        <div class="banner-img">
                            <br>
                         <a class="btn btn-success" href="add_topup.php">Add Funds</a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
                                                              <?php
              $sp=$rowuser['id'];
$query=mysqli_query($con,"select *  from  user where type='3' and sponsor_id='$sp' and status='Pending'")or die(mysqli_error());
$count=mysqli_num_rows($query);
              ?>
            
            
                                        <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <div class="card">
                <div class="card-statistic-4">
                  <div class="align-items-center justify-content-between">
                    <div class="row ">
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pr-0 pt-3">
                        <div class="card-content">
                          <h5 class="font-15">Pending Rider Application</h5>
                 <h2 class="mb-3 font-26"><?php echo $count;?></h2>
                         
                        </div>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pl-0">
                        <div class="banner-img">
                          <img src="assets/img/banner/4.png" alt="">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            

                                    <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <div class="card">
                <div class="card-statistic-4">
                  <div class="align-items-center justify-content-between">
                    <div class="row ">
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pr-0 pt-3">
                        <div class="card-content">
                          <h5 class="font-15">Total Lump Sum Rewards</h5>
                 <h2 class="mb-3 font-18">&#8369; <?php echo number_format($row['amount'],2);?></h2>
                         
                        </div>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pl-0">
                        <div class="banner-img">
                          <img src="assets/img/banner/4.png" alt="">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            
            
            
                                                  <?php
              $sp=$rowuser['id'];
$query=mysqli_query($con,"select *  from  user where type='3' and sponsor_id='$sp'")or die(mysqli_error());
$count=mysqli_num_rows($query);
              ?>
            <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <div class="card">
                <div class="card-statistic-4">
                  <div class="align-items-center justify-content-between">
                    <div class="row ">
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pr-0 pt-3">
                        <div class="card-content">
                          <h5 class="font-15">My Rider</h5>
                    <h2 class="mb-3 font-18"><?php echo $count;?></h2>
                         
                        </div>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pl-0">
                        <div class="banner-img">
                          <img src="assets/img/banner/2.png" alt="">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
               
                        <?php
              
$query=mysqli_query($con,"select sum(amount_final) as amount from  withdrawals where status='Pending' and user_id='$ses' ")or die(mysqli_error());
$row=mysqli_fetch_array($query);
              ?>   
            
                                    <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <div class="card">
                <div class="card-statistic-4">
                  <div class="align-items-center justify-content-between">
                    <div class="row ">
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pr-0 pt-3">
                        <div class="card-content">
                          <h5 class="font-15">Total Pending Withdrawals</h5>
                           <h2 class="mb-3 font-18">&#8369; <?php echo number_format($row['amount'],2);?></h2>
                         
                        </div>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pl-0">
                        <div class="banner-img">
                          <img src="assets/img/banner/4.png" alt="">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            
            
               <?php
              
$query=mysqli_query($con,"select sum(amount_final) as amount from  withdrawals where status='Completed' and user_id='$ses' ")or die(mysqli_error());
$row=mysqli_fetch_array($query);
              ?>  
            
                                    <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <div class="card">
                <div class="card-statistic-4">
                  <div class="align-items-center justify-content-between">
                    <div class="row ">
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pr-0 pt-3">
                        <div class="card-content">
                          <h5 class="font-15">Total Completed Withdrawals</h5>
                  <h2 class="mb-3 font-18">&#8369; <?php echo number_format($row['amount_final'],2);?></h2>
                         
                        </div>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6 pl-0">
                        <div class="banner-img">
                          <img src="assets/img/banner/4.png" alt="">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            
            
            
            
            
                      <div class="col-12">
                <div class="card">
                  <div class="card-header">
                    <h4>On-Going Transaction</h4>
                  </div>
                  <div class="card-body">
                    <div class="table-responsive">
                      <table class="table table-striped table-hover" id="tableExport" style="width:100%;">
                        <thead>
                          <tr>
                              <th>#</th>
                               <th>Fullname</th>
                                <th>Amount</th>
                           
                           
                            <th>Date Added</th>
                             
                         
                          </tr>
                        </thead>
                        <tbody>
                            
                           				<?php

$uid=$_SESSION['id'];

$query=mysqli_query($con,"select * from  reward_history where user_id='$uid' order by id asc")or die(mysqli_error());
while($row=mysqli_fetch_array($query)){  

$sid=$row['user_id'];
$querys=mysqli_query($con,"select * from  user where id='$sid' order by lastname asc")or die(mysqli_error());
$rows=mysqli_fetch_array($querys);


$sids=$row['transfer_by'];
$queryss=mysqli_query($con,"select * from  user where id='$sids' order by lastname asc")or die(mysqli_error());
$rows2=mysqli_fetch_array($queryss);

$count++;
				  ?> 
                            
                        
                            
                          <tr>
                            <td><?php echo $count?></td>
                            
                            
                                          
                                      <td><?php echo strtoupper($rows['lastname'])?>, <?php echo strtoupper($rows['firstname'])?> <?php echo strtoupper($rows['middlename'])?></td>
                                      
                                      
                                                    <td><?php echo number_format($row['amount'],2)?></td>
                                                    
                                                    
                                                                  
                                                                                <td><?php echo $row['date_added']?></td>
                                                                                             
                                                                                                                                        	   
                                                                                                                     	   
					         
                                                                                                                                            
                                                                  
                          </tr>
                          
                          
                          <?php
}
                          
                          ?>
                    
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            
            
            
            
            
            
            
            
                                         <?php
            }
            
            ?> 
            
            
            
            
            
            
            
            
            
            
          </div>
        <!--  <div class="row">
            <div class="col-12 col-sm-12 col-lg-12">
              <div class="card ">
                <div class="card-header">
                  <h4>Revenue chart</h4>
                  <div class="card-header-action">
              
                  
                  </div>
                </div>
                <div class="card-body">
                  <div class="row">
                    <div class="col-lg-9">
                      <div id="chart1"></div>
                      <div class="row mb-0">
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
                          <div class="list-inline text-center">
                            <div class="list-inline-item p-r-30"><i data-feather="arrow-up-circle"
                                class="col-green"></i>
                              <h5 class="m-b-0">0Php</h5>
                              <p class="text-muted font-14 m-b-0">Weekly Earnings</p>
                            </div>
                          </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
                          <div class="list-inline text-center">
                            <div class="list-inline-item p-r-30"><i data-feather="arrow-down-circle"
                                class="col-orange"></i>
                              <h5 class="m-b-0">0Php</h5>
                              <p class="text-muted font-14 m-b-0">Monthly Earnings</p>
                            </div>
                          </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-4">
                          <div class="list-inline text-center">
                            <div class="list-inline-item p-r-30"><i data-feather="arrow-up-circle"
                                class="col-green"></i>
                              <h5 class="mb-0 m-b-0">0Php</h5>
                              <p class="text-muted font-14 m-b-0">Yearly Earnings</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-lg-3">
                      <div class="row mt-5">
                        <div class="col-7 col-xl-7 mb-3">Total customers</div>
                        <div class="col-5 col-xl-5 mb-3">
                          <span class="text-big">0</span>
                       
                        </div>
                        <div class="col-7 col-xl-7 mb-3">Total Income</div>
                        <div class="col-5 col-xl-5 mb-3">
                          <span class="text-big">0</span>
                      
                        </div>
                
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>-->
          
        </section>

      </div>
     <?php
     
     include('footer.php');
     
     ?>
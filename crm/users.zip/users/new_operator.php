<?php

include('header.php');

?>
      <!-- Main Content -->
  <div class="main-content">
        <section class="section">
          <div class="section-body">
              
              
              
              
            <div class="row mt-sm-4">
        
              
              <div class="col-12 col-md-6 col-lg-6">
                <div class="card">
                 <?php



?>




         	<?php

		  		  
if(isset($_POST['signin']))
{
    $id_number=$_POST['id_number'];
    
    		  $group_name=$_GET['group_name'];
		  $pos=$_GET['pos'];
		  		  $connect_to=$_GET['id'];
    

    
    
    
    

    
    
$query21a1c=mysqli_query($con,"select * from  code where code='$id_number' and status='' ")or die(mysqli_error());
$row21a1ac=mysqli_num_rows($query21a1c);
$row21a1act=mysqli_fetch_array($query21a1c);
if($row21a1ac>=1){
    
$password=$row21a1act['pin'];
$username=$_POST['id_number'];
$firstname=$_POST['firstname'];
$middlename=$_POST['middlename'];
$lastname=$_POST['lastname'];
$contact=$_POST['contact'];
$email=$_POST['email'];
$gender=$_POST['gender'];
$status="Active";
$type="2";
$date=date("Y-m-d H:i");
$idd=$_SESSION['id'];

	$query21a1=mysqli_query($con,"select * from  user where username='$username' ")or die(mysqli_error());
$row21a1a=mysqli_num_rows($query21a1);
if($row21a1a<=0){

		 ///mysqli_query($con,"INSERT INTO user(sponsor_id,id_number,firstname,middlename,lastname,status,email,contact,date_added,type,username,password) VALUES('$idd','$id_number','$firstname','$middlename','$lastname','$status','$email','$contact','$date','$type','$username','$password')")or die(mysqli_error($con));
		  
		  $group_name=$_GET['group_name'];
		  $pos=$_GET['pos'];
		  		  $connect_to=$_GET['id'];
		  		  
	$tin=$_POST['tin'];
		  	$address=$_POST['address'];		  

$sql = "INSERT INTO user (address,tin,gender,sponsor_id,id_number,firstname,middlename,lastname,status,email,contact,date_added,type,username,password)
VALUES ('$address','$tin','$gender','$idd','$id_number','$firstname','$middlename','$lastname','$status','$email','$contact','$date','$type','$username','$password')";

if ($conn->query($sql) === TRUE) {
  $last_id = $conn->insert_id;

} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

 $rand_start = rand(10,99);
$id_n=date("ymdH")."".$rand_start;
 $group_new2=$id_n."0";


		  		  
		  		  
		  		  
		 
		  
		  $stat="Used by ".$firstname." ".$lastname;
		  
		  
		  	  	mysqli_query($con,"update code set status='$stat' , operator_id='$last_id' where code='$id_number' ")or die(mysqli_error());
		  	  	
		  	  	
		  	  	
		  	  	



mysqli_query($con,"INSERT INTO groupings(group_name,operator_id,date_added,status,connect_to,pos) VALUES('$group_new2','$last_id','','Waiting','0','1')")or die(mysqli_error($con));


mysqli_query($con,"INSERT INTO groupings(group_name,operator_id,date_added,status,connect_to,pos) VALUES('$group_new2','0','','Pending','0','2')")or die(mysqli_error($con));

mysqli_query($con,"INSERT INTO groupings(group_name,operator_id,date_added,status,connect_to,pos) VALUES('$group_new2','0','','Pending','0','3')")or die(mysqli_error($con));

mysqli_query($con,"INSERT INTO groupings(group_name,operator_id,date_added,status,connect_to,pos) VALUES('$group_new2','0','','Pending','0','4')")or die(mysqli_error($con));

mysqli_query($con,"INSERT INTO groupings(group_name,operator_id,date_added,status,connect_to,pos) VALUES('$group_new2','0','','Pending','0','5')")or die(mysqli_error($con));

mysqli_query($con,"INSERT INTO groupings(group_name,operator_id,date_added,status,connect_to,pos) VALUES('$group_new2','0','','Pending','0','6')")or die(mysqli_error($con));
mysqli_query($con,"INSERT INTO groupings(group_name,operator_id,date_added,status,connect_to,pos) VALUES('$group_new2','0','','Pending','0','7')")or die(mysqli_error($con));
mysqli_query($con,"INSERT INTO groupings(group_name,operator_id,date_added,status,connect_to,pos) VALUES('$group_new2','0','','Pending','0','8')")or die(mysqli_error($con));

mysqli_query($con,"INSERT INTO groupings(group_name,operator_id,date_added,status,connect_to,pos) VALUES('$group_new2','0','','Pending','0','9')")or die(mysqli_error($con));
mysqli_query($con,"INSERT INTO groupings(group_name,operator_id,date_added,status,connect_to,pos) VALUES('$group_new2','0','','Pending','0','10')")or die(mysqli_error($con));
mysqli_query($con,"INSERT INTO groupings(group_name,operator_id,date_added,status,connect_to,pos) VALUES('$group_new2','0','','Pending','0','11')")or die(mysqli_error($con));
mysqli_query($con,"INSERT INTO groupings(group_name,operator_id,date_added,status,connect_to,pos) VALUES('$group_new2','0','','Pending','0','12')")or die(mysqli_error($con));
mysqli_query($con,"INSERT INTO groupings(group_name,operator_id,date_added,status,connect_to,pos) VALUES('$group_new2','0','','Pending','0','13')")or die(mysqli_error($con));
mysqli_query($con,"INSERT INTO groupings(group_name,operator_id,date_added,status,connect_to,pos) VALUES('$group_new2','0','','Pending','0','14')")or die(mysqli_error($con));
mysqli_query($con,"INSERT INTO groupings(group_name,operator_id,date_added,status,connect_to,pos) VALUES('$group_new2','0','','Pending','0','15')")or die(mysqli_error($con));


    	
		  	  	
		  	  	
		  	  	
		  	  	
		  	  	
		  	  	

		  
		$conn->close();
?>


	<script type="text/javascript">
    window.setTimeout(function() {
        window.location.href='new_operator.php';
    }, 1000);
</script>
		
		
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>


<script type="text/javascript">
JSalert333();
function JSalert333(){

swal("Success!", "Successfully Register!", "success");
 
}
</script>



<?php
}else{
    ?>
    
    
    <script type="text/javascript">
    window.setTimeout(function() {
        window.location.href='new_operator.php';
    }, 1000);
</script>
		
		
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>


<script type="text/javascript">
JSalert();
function JSalert(){

swal("Ops!", "Username Already Used!", "warning");
 
}
</script>
    
    
    <?php
    
    
    
    
    
}
}else{
    ?>
    
    
     <script type="text/javascript">
    window.setTimeout(function() {
        window.location.href='new_operator.php';
    }, 1000);
</script>
		
		
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>


<script type="text/javascript">
JSalert33();
function JSalert33(){

swal("Ops!", "Incorrect Code or already used!!", "warning");
 
}
</script>
    
    
    <?php
    
    
    
    
    
}
}
 
    

$rand_start = rand(1000,9999);
$id_n=date("Ymd")."".$rand_start;

?>           
                    
                    
                    
                    
                    
                    
                  <form method="POST">
                    <div class="card-header">
                                 
                      <h4>New Operator Registration<br>
                      <hr>Please provide the following information.</h4>
                    </div>
                    <div class="card-body">
                        
                 <div class="form-group">
                        <label>Operator Code *</label>
                        <input name="id_number"  type="text" class="form-control" required="">
                      </div>
             
             
          
                         

                               <div class="form-group">
                        <label>Firstname *</label>
                        <input name="firstname" type="text" class="form-control" required="">
                      </div>
               
                                  <div class="form-group">
                        <label>Middlename *</label>
                        <input name="middlename" type="text" class="form-control" required="">
                      </div>
                      
                                         <div class="form-group">
                        <label>Lastname *</label>
                        <input name="lastname" type="text" class="form-control" required="">
                      </div>
                      
                      
                      
                                         <div class="form-group">
                        <label>Email *</label>
                        <input name="email" type="email" class="form-control" required="">
                      </div>
                      
                                         <div class="form-group">
                        <label>Contact no. *</label>
                        <input name="contact" type="text" class="form-control" required="">
                      </div>
                      
                                         <div class="form-group">
                        <label>Gender</label>
                        <select name="gender" type="text" class="form-control" required="">
                            <option value="">--Please Select--</option>
                            <option>Male</option>
                              <option>Female</option>
                            </select>
                      </div>
                                                              <div class="form-group">
                        <label>Complete Address *</label>
                        <textarea name="address" type="text" class="form-control" required=""></textarea>
                      </div>
                                                   <div class="form-group">
                        <label>TIN No. *</label>
                        <input name="tin" type="text" class="form-control" required="">
                      </div>
                      
                      
                      
                    </div>
                    <div class="card-footer text-right">
                      <button name="signin" class="btn btn-primary">Register</button>
                    </div>
                  </form>
                </div>
               
              </div>
            
              
              
              
              
              
             
            </div>
            
            
            
            
            
            
            
          </div>
        </section>
       
      </div>
     <?php
     
     include('footer.php');
     
     ?>
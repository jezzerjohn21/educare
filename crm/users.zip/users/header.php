<!DOCTYPE html>
<html lang="en">

   <?php
         include('../dist/dbcon.php');
  
error_reporting(0);

session_start();

if($_SESSION['id']>=1){

}else{
	header('Location:../');
}
date_default_timezone_set("Asia/Manila"); 

         $sid=$_SESSION['id'];

$queryusers=mysqli_query($con,"SELECT * FROM user WHERE id='$sid' ")or die(mysqli_error($con));
$rowuser=mysqli_fetch_array($queryusers);



         ?>
          
          
          
          

                   <?php
         include('../dist/dbcon.php');
  
error_reporting(0);

session_start();

if($_SESSION['id']>=1){

}else{
	header('Location:../');
}
date_default_timezone_set("Asia/Manila"); 

         $sid=$_SESSION['id'];

$queryusers=mysqli_query($con,"SELECT * FROM user WHERE id='$sid' ")or die(mysqli_error($con));
$rowuser=mysqli_fetch_array($queryusers);



         ?>
          
<!-- index.html  21 Nov 2019 03:44:50 GMT -->
<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
  <title>Booq</title>
  <!-- General CSS Files -->
  <link rel="stylesheet" href="assets/css/app.min.css">
  <!-- Template CSS -->
  <link rel="stylesheet" href="assets/css/style.css">
  <link rel="stylesheet" href="assets/css/components.css">
  <!-- Custom style CSS -->
  <link rel="stylesheet" href="assets/css/custom.css">
<link rel="icon" href="../../logo (2).png">
</head>

<body>
 <!-- <div class="loader"></div>-->
  <div id="app">
    <div class="main-wrapper main-wrapper-1">
      <div class="navbar-bg"></div>
      <nav class="navbar navbar-expand-lg main-navbar sticky">
        <div class="form-inline mr-auto">
          <ul class="navbar-nav mr-3">
            <li><a href="#" data-toggle="sidebar" class="nav-link nav-link-lg
									collapse-btn"> <i data-feather="align-justify"></i></a></li>
     

          </ul>
        </div>
        <ul class="navbar-nav navbar-right">
            
              <li class="dropdown"><a href="#" data-toggle="dropdown"
              class="nav-link dropdown-toggle nav-link-lg nav-link-user"> 
              
              
             <b><font color="#6c757d" size="2px"><i class="fas fa-money-check-alt"></i> MY TRANSACTION</font></b>
                <span class="d-sm-none d-lg-inline-block">
                    
                    
                </span></a>
            <div class="dropdown-menu dropdown-menu-right pullDown">
              <div class="dropdown-title">Enchasment</div>
              
              
              
              <a href="withdrawals.php" class="dropdown-item has-icon"> <i class="fas fa-money-check-alt"></i> Withdrawals
              </a> 
                       <a href="withdrawals_history.php" class="dropdown-item has-icon"> <i class="fas fa-money-check-alt"></i> Withdrawals History
              </a> 


    <div class="dropdown-divider"></div>

              
              <a href="earning_history.php" class="dropdown-item has-icon"> <i class="fas fa-book"></i>
                Earning History
              </a>
              
              
                  <div class="dropdown-divider"></div>
          
      
            </div>
          </li>
            
            
            
            


  
  
  
  
        <!-- <li class="dropdown dropdown-list-toggle"><a href="#" data-toggle="dropdown"
              class="nav-link notification-toggle nav-link-lg"><i data-feather="bell" class="bell"></i>
            </a>
            <div class="dropdown-menu dropdown-list dropdown-menu-right pullDown">
              <div class="dropdown-header">
                Notifications
           
              </div>
              <div class="dropdown-list-content dropdown-list-icons">
                <a href="#" class="dropdown-item dropdown-item-unread"> <span
                    class="dropdown-item-icon bg-primary text-white"> <i class="fas
												fa-code"></i>
                  </span> <span class="dropdown-item-desc"> Template update is
                    available now! <span class="time">2 Min
                      Ago</span>
                  </span>
                </a> <a href="#" class="dropdown-item"> <span class="dropdown-item-icon bg-info text-white"> <i class="far
												fa-user"></i>
                  </span> <span class="dropdown-item-desc"> <b>You</b> and <b>Dedik
                      Sugiharto</b> are now friends <span class="time">10 Hours
                      Ago</span>
                  </span>
                </a> <a href="#" class="dropdown-item"> <span class="dropdown-item-icon bg-success text-white"> <i
                      class="fas
												fa-check"></i>
                  </span> <span class="dropdown-item-desc"> <b>Kusnaedi</b> has
                    moved task <b>Fix bug header</b> to <b>Done</b> <span class="time">12
                      Hours
                      Ago</span>
                  </span>
                </a> <a href="#" class="dropdown-item"> <span class="dropdown-item-icon bg-danger text-white"> <i
                      class="fas fa-exclamation-triangle"></i>
                  </span> <span class="dropdown-item-desc"> Low disk space. Let's
                    clean it! <span class="time">17 Hours Ago</span>
                  </span>
                </a> <a href="#" class="dropdown-item"> <span class="dropdown-item-icon bg-info text-white"> <i class="fas
												fa-bell"></i>
                  </span> <span class="dropdown-item-desc"> Welcome to Otika
                    template! <span class="time">Yesterday</span>
                  </span>
                </a>
              </div>
              <div class="dropdown-footer text-center">
                <a href="notification.php">View All <i class="fas fa-chevron-right"></i></a>
              </div>
            </div>
          </li>
          
          -->
          
      
          
          
          
          <li class="dropdown"><a href="#" data-toggle="dropdown"
              class="nav-link dropdown-toggle nav-link-lg nav-link-user"> 
              
              
              <?php
              if($rowuser['gender']=="Male"){
              ?>
              <img alt="image" src="male.fw.png"
                class="user-img-radious-style"> 
                
                
                     <?php
              }
              ?>
                       
              <?php
              if($rowuser['gender']=="Female"){
              ?>
              <img alt="image" src="female.fw.png"
                class="user-img-radious-style"> 
                
                
                     <?php
              }
              ?>
                <span class="d-sm-none d-lg-inline-block">
                    
                    
                </span></a>
            <div class="dropdown-menu dropdown-menu-right pullDown">
              <div class="dropdown-title"><?php echo $rowuser['firstname'];?> <?php echo $rowuser['lastname'];?></div>
              
              
              
              <a href="profile.php" class="dropdown-item has-icon"> <i class="far
										fa-user"></i> Profile
              </a> 
              




              
              <a href="changepass.php" class="dropdown-item has-icon"> <i class="fas fa-cog"></i>
                Change Password
              </a>
              
              
              
              <div class="dropdown-divider"></div>
              <a href="logout.php" class="dropdown-item has-icon text-danger"> <i class="fas fa-sign-out-alt"></i>
                Logout
              </a>
            </div>
          </li>
        </ul>
      </nav>
      <div class="main-sidebar sidebar-style-2">
        <aside id="sidebar-wrapper">
          <div class="sidebar-brand">
            <a href="index.html"> <img alt="image" src="../icon.fw.png" class="header-logo" /> <span
                class="logo-name"><!--Otika--></span>
            </a>
          </div>
          <ul class="sidebar-menu">
            <li class="menu-header">Main</li>
            

            
            
            
            <li class="dropdown <?php 
if(basename($_SERVER['PHP_SELF'])=="dashboard.php"){ echo"active"; }
?> ">
              <a href="dashboard.php" class="nav-link"><i data-feather="monitor"></i><span>Dashboard</span></a>
            </li>
            
            
        
            
           <?php
            if($rowuser['type']==2){
            
            ?>
            
                        
            <li class="dropdown <?php 
if(basename($_SERVER['PHP_SELF'])=="earnings.php"){ echo"active"; }
?> ">
              <a href="earnings.php" class="nav-link"><i data-feather="book"></i><span>Lump Sum Bonus</span></a>
            </li>
            
            
            
            
            

                        
                              <li class="menu-header">Users</li>
                       
                        <li class="dropdown <?php 
if(basename($_SERVER['PHP_SELF'])=="operator_register.php"){ echo"active"; }
?> ">
              <a href="operator_register.php" class="nav-link"><i data-feather="book"></i><span>Genealogy</span></a>
            </li>
                                   
            <li class="dropdown <?php 
if(basename($_SERVER['PHP_SELF'])=="rider_register.php" || basename($_SERVER['PHP_SELF'])=="rider_lists.php" ){ echo"active"; }
?>">
                
                                                                          <?php
              $sp=$rowuser['id'];
$query=mysqli_query($con,"select *  from  user where type='3' and sponsor_id='$sp' and status='Pending'")or die(mysqli_error());
$count=mysqli_num_rows($query);
              ?>

              <a href="#" class="menu-toggle nav-link has-dropdown"><i
                  data-feather="users"></i><span>Riders</span></a>
              <ul class="dropdown-menu">
                <li><a class="nav-link" href="rider_register.php">Register</a></li>
                  <li><a class="nav-link" href="rider_lists_pending.php">Rider's Pending Lists(<?php echo $count;?>)</a></li>
                  <li><a class="nav-link" href="rider_lists.php">Rider's Lists</a></li>
       
              </ul>
            </li>
            
            
            
            
            
           <li class="menu-header">MISC</li>  
            
            
            
               <li class="dropdown <?php 
if(basename($_SERVER['PHP_SELF'])=="rfundings_history_o.php"){ echo"active"; }
?> ">
              <a href="rfundings_history_o.php" class="nav-link"><i data-feather="trending-up"></i><span>Rider's Funding History</span></a>
            </li>
            
            
             <li class="dropdown <?php 
if(basename($_SERVER['PHP_SELF'])=="ofundings_history_o.php"){ echo"active"; }
?> ">
              <a href="ofundings_history_o.php" class="nav-link"><i data-feather="trending-up"></i><span>My Funding History</span></a>
            </li>
            
            

            
               <?php
            }
            
            ?>
            
            <?php
            if($rowuser['type']==0){
            
            ?>
            
                   <li class="dropdown <?php 
if(basename($_SERVER['PHP_SELF'])=="generate.php" || basename($_SERVER['PHP_SELF'])=="code_lists.php" || basename($_SERVER['PHP_SELF'])=="code_lists_used.php"){ echo"active"; }
?>">
              <a href="#" class="menu-toggle nav-link has-dropdown"><i
                  data-feather="briefcase"></i><span>Codes</span></a>
              <ul class="dropdown-menu">
                     <li><a class="nav-link" href="generate.php">Generate Code</a></li>
                <li class="dropdown">
                  <a href="#" class="has-dropdown">List of Codes</a>
                  <ul class="dropdown-menu">
            
                     <li><a class="nav-link" href="code_lists.php">Unused Codes</a></li>
                       <li><a class="nav-link" href="code_lists_used.php">Used Codes</a></li>
                  </ul>
                </li>
              </ul>
            </li>     
                   
          <?php
            }
            
            ?>
              <?php
      
            if($rowuser['type']==1|| $rowuser['type']==0){
            
            ?>
            
            
  
                        
              <li class="menu-header">Withdrawals</li>
            

            
                        
                        <li class="dropdown <?php 
if(basename($_SERVER['PHP_SELF'])=="wallet_operator.php" || basename($_SERVER['PHP_SELF'])=="wallet_rider.php" ){ echo"active"; }
?>">
                            
                            <?php
                            
$query2w=mysqli_query($con,"select * from  withdrawals where status='Pending'")or die(mysqli_error());
$row2w=mysqli_num_rows($query2w);
                            
                            ?>
              <a href="#" class="menu-toggle nav-link has-dropdown"><i
                  data-feather="plus-square"></i><span>Withdrawals(<?php echo $row2w;?>)</span></a>
              <ul class="dropdown-menu">
                <li><a class="nav-link" href="pending_withdrawals.php">Pending Withdrawals</a></li>
                
                
                    <li><a class="nav-link" href="hold_withdrawals.php">Hold Withdrawals</a></li>
                    
                  <li><a class="nav-link" href="completed_withdrawals.php">Completed Withdrawals</a></li>
        
              </ul>
            </li>
            
            
               <li class="menu-header">Wallet</li>
            

            
                        
                        <li class="dropdown <?php 
if(basename($_SERVER['PHP_SELF'])=="wallet_operator.php" || basename($_SERVER['PHP_SELF'])=="wallet_rider.php" ){ echo"active"; }
?>">
              <a href="#" class="menu-toggle nav-link has-dropdown"><i
                  data-feather="plus-square"></i><span>Fund Transfering</span></a>
              <ul class="dropdown-menu">
                <li><a class="nav-link" href="wallet_operator.php">Operator's Top up</a></li>
                  <li><a class="nav-link" href="wallet_rider.php">Rider's Load Top up</a></li>
        
              </ul>
            </li>
                                    
                              <li class="menu-header">Users</li>
                       
            <li class="dropdown <?php 
if(basename($_SERVER['PHP_SELF'])=="operator_register.php" || basename($_SERVER['PHP_SELF'])=="operator_lists.php" || basename($_SERVER['PHP_SELF'])=="operator_group.php"){ echo"active"; }
?>">
              <a href="#" class="menu-toggle nav-link has-dropdown"><i
                  data-feather="users"></i><span>Operator</span></a>
              <ul class="dropdown-menu">
                  
                  
                                       <?php
      
            if($rowuser['type']==0|| $rowuser['type']==1){
            
            ?>
                        <li><a class="nav-link" href="new_operator.php">New Operator</a></li>
                  
                       <?php
            }
            if($rowuser['type']==0|| $rowuser['type']==2){
            
            ?>
                  
                  
                <li><a class="nav-link" href="operator_register.php">Genealogy</a></li>
                     <?php
      
            }
            
            ?>
                
           <?php
      
            if($rowuser['type']==1|| $rowuser['type']==0){
            
            ?>
                
                
                  <li><a class="nav-link" href="operator_lists.php">Operator's Lists</a></li>
                  
                  
                            <?php
            }
            
            ?>
                  
                  
                  
     
              </ul>
            </li>
                      <?php
              $sp=$rowuser['id'];
$query=mysqli_query($con,"select *  from  user where type='3' and sponsor_id='$sp' and status='Pending'")or die(mysqli_error());
$count=mysqli_num_rows($query);
              ?>

               
            <li class="dropdown <?php 
if(basename($_SERVER['PHP_SELF'])=="rider_register.php" || basename($_SERVER['PHP_SELF'])=="rider_lists.php" ){ echo"active"; }
?>">
              <a href="#" class="menu-toggle nav-link has-dropdown"><i
                  data-feather="users"></i><span>Riders</span></a>
              <ul class="dropdown-menu">
                <li><a class="nav-link" href="rider_register.php">Register</a></li>
                             <li><a class="nav-link" href="rider_lists_pending.php">Rider's Pending Lists(<?php echo $count;?>)</a></li>
                  <li><a class="nav-link" href="rider_lists.php">Rider's Lists</a></li>
       
              </ul>
            </li>
                        <li class="dropdown <?php 
if(basename($_SERVER['PHP_SELF'])=="customer_lists.php"  ){ echo"active"; }
?>">
              <a href="#" class="menu-toggle nav-link has-dropdown"><i
                  data-feather="users"></i><span>Customer</span></a>
              <ul class="dropdown-menu">
            
                  <li><a class="nav-link" href="customer_lists.php">Customer's Lists</a></li>
       
              </ul>
            </li>
            
            
 
            
                 <?php
            }
            if($rowuser['type']==0){
            
            ?> 

                              <li class="menu-header">News And Announcement</li>
                        
            
               <li class="dropdown ">
              <a href="#" class="menu-toggle nav-link has-dropdown"><i
                  data-feather="book-open"></i><span>News/Announcement</span></a>
              <ul class="dropdown-menu">
        <li><a class="nav-link" href="add_news.php">Add New</a></li>
    <li><a class="nav-link" href="news.php">Lists</a></li>
   
              </ul>
            </li>
            
                          <li class="menu-header">Maintenance</li>
                        
                        
                        
                        
                        
                        <li class="dropdown ">
              <a href="#" class="menu-toggle nav-link has-dropdown"><i
                  data-feather="book-open"></i><span>Rates</span></a>
              <ul class="dropdown-menu">
        <li><a class="nav-link" href="rates.php">Update Rates</a></li>
   
   
              </ul>
            </li>
                                    
                        
                        <li class="dropdown ">
              <a href="#" class="menu-toggle nav-link has-dropdown"><i
                  data-feather="book-open"></i><span>Company Details</span></a>
              <ul class="dropdown-menu">
        <li><a class="nav-link" href="company.php">Update </a></li>
   
   
              </ul>
            </li>
            
            
               <li class="dropdown ">
              <a href="#" class="menu-toggle nav-link has-dropdown"><i
                  data-feather="book-open"></i><span>Mobile Application Front</span></a>
              <ul class="dropdown-menu">
        <li><a class="nav-link" href="add_banner.php">Add Banner/Ads</a></li>
    <li><a class="nav-link" href="banner.php">Lists</a></li>
   
              </ul>
            </li>
            
                                                <li class="dropdown ">
              <a href="#" class="menu-toggle nav-link has-dropdown"><i
                  data-feather="server"></i><span>What you need to know? </span></a>
              <ul class="dropdown-menu">
        <li><a class="nav-link" href="add_file.php">Add </a></li>
        <li><a class="nav-link" href="file.php">File</a></li>
   
              </ul>
            </li>
            
                                    <li class="dropdown ">
              <a href="#" class="menu-toggle nav-link has-dropdown"><i
                  data-feather="server"></i><span>Destination </span></a>
              <ul class="dropdown-menu">
        <li><a class="nav-link" href="add_destination.php">Add Destination</a></li>
        <li><a class="nav-link" href="destination.php">Destination</a></li>
   
              </ul>
            </li>
            
               <li class="menu-header">Booq User's</li>
            
            
                        <li class="dropdown <?php 
if(basename($_SERVER['PHP_SELF'])=="staff_register.php" || basename($_SERVER['PHP_SELF'])=="staff_lists.php" ){ echo"active"; }
?>">
              <a href="#" class="menu-toggle nav-link has-dropdown"><i
                  data-feather="users"></i><span>Staff</span></a>
              <ul class="dropdown-menu">
                <li><a class="nav-link" href="staff_register.php">Register</a></li>
                  <li><a class="nav-link" href="staff_lists.php">Staff's Lists</a></li>
       
              </ul>
            </li>
                                    <li class="dropdown <?php 
if(basename($_SERVER['PHP_SELF'])=="admin_register.php" || basename($_SERVER['PHP_SELF'])=="admin_lists.php" ){ echo"active"; }
?>">
              <a href="#" class="menu-toggle nav-link has-dropdown"><i
                  data-feather="users"></i><span>Administrator</span></a>
              <ul class="dropdown-menu">
                <li><a class="nav-link" href="admin_register.php">Register</a></li>
                  <li><a class="nav-link" href="admin_lists.php">Administrator's Lists</a></li>
       
              </ul>
            </li>
                           <li class="menu-header">Reports</li>
                                                
            <li class="dropdown <?php 
if(basename($_SERVER['PHP_SELF'])=="booking_history.php"){ echo"active"; }
?> ">
              <a href="booking_history.php" class="nav-link"><i data-feather="trending-up"></i><span>Booking History</span></a>
            </li>
            
                        
            <li class="dropdown <?php 
if(basename($_SERVER['PHP_SELF'])=="payout_history.php"){ echo"active"; }
?> ">
              <a href="payout_history.php" class="nav-link"><i data-feather="trending-up"></i><span>Withdrawal's History</span></a>
            </li>
            
               <li class="dropdown <?php 
if(basename($_SERVER['PHP_SELF'])=="rfundings_history.php"){ echo"active"; }
?> ">
              <a href="rfundings_history.php" class="nav-link"><i data-feather="trending-up"></i><span>Rider's Funding History</span></a>
            </li>
            
            
             <li class="dropdown <?php 
if(basename($_SERVER['PHP_SELF'])=="ofundings_history.php"){ echo"active"; }
?> ">
              <a href="ofundings_history.php" class="nav-link"><i data-feather="trending-up"></i><span>Operator's Funding History</span></a>
            </li>
            
                         <li class="dropdown <?php 
if(basename($_SERVER['PHP_SELF'])=="lfundings_history.php"){ echo"active"; }
?> ">
              <a href="lfundings_history.php" class="nav-link"><i data-feather="trending-up"></i><span>Lump Sum History</span></a>
            </li>
            
            
              <li class="menu-header">History Logs</li>
            
            
                         <li class="dropdown <?php 
if(basename($_SERVER['PHP_SELF'])=="logs.php"){ echo"active"; }
?> ">
              <a href="logs.php" class="nav-link"><i data-feather="tablet"></i><span>Logs</span></a>
            </li>

                                  <?php
            }
            
            ?>
            
            
                              
                                <li class="dropdown <?php 
if(basename($_SERVER['PHP_SELF'])=="faqs.php"){ echo"active"; }
?> ">
              <a href="faqs.php" class="nav-link"><i data-feather="book-open"></i><span>What you need to know?</span></a>
            </li >                          
            

          </ul>
        </aside>
      </div>